export class CreateInstitucionDto {}
