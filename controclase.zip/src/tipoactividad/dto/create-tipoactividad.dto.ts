export class CreateTipoactividadDto {}
