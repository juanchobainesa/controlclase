export class CreateGradoDto {}
