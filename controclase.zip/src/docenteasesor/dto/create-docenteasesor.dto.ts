export class CreateDocenteasesorDto {}
