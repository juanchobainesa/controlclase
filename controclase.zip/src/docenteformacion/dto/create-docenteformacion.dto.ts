export class CreateDocenteformacionDto {

     nombre : string
     apellido : string
     email : string
     celular : string


}
