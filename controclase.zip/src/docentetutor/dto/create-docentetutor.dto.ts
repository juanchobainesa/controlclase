export class CreateDocentetutorDto {}
